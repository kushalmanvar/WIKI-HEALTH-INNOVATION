# WIKI-HEALTH-INNOVATION-SE-PROJECT
It is a web platform which can be used by any medical / health care faculty in order to search for latest drugs or equipment's that are available in the market for them or to research upon them. It also contain's a Google like search engine which can be used to make any generic search like WHO or Corona and it will display you the links and images related to that topic. 

Home Screen for our Web Application
![](https://raw.githubusercontent.com/HusainKagalwala07/WIKI-HEALTH-INNOVATION-SE-PROJECT/master/img/ss1.png)

Feature #1 Medicine Search
![](https://raw.githubusercontent.com/HusainKagalwala07/WIKI-HEALTH-INNOVATION-SE-PROJECT/master/img/ss2.png)

Feature #2 Equipment or Device Search 
![](https://raw.githubusercontent.com/HusainKagalwala07/WIKI-HEALTH-INNOVATION-SE-PROJECT/master/img/ss3.png)

Feature #3 Generalize Google Search
![](https://raw.githubusercontent.com/HusainKagalwala07/WIKI-HEALTH-INNOVATION-SE-PROJECT/master/img/ss4.png)

Feature #4 Substitute Medicine Search
![](https://raw.githubusercontent.com/HusainKagalwala07/WIKI-HEALTH-INNOVATION-SE-PROJECT/master/img/ss5.png)
