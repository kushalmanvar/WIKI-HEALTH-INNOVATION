<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Wiki Health Innovation-Home Page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php"><img src="img/heart.png">&nbsp;&nbsp;Wiki Health Innovation </a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
<!--
		   <li class="nav-item">
              <a class="nav-link" href="register.php">Register</a>
            </li>
			<li class="nav-item">
              <a class="nav-link" href="login.php">Login</a>
            </li>
-->
            <li class="nav-item">
              <a class="nav-link" href="about.php">About</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="services.php">Services</a>
<!--
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact</a>
            </li>
-->
            
          </ul>
        </div>
      </div>
    </nav>

    <header>
      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner" role="listbox">
          <!-- Slide One - Set the background image for this slide in the line below -->
          <div class="carousel-item active" style="background-image: url('img/image1.jpg')">
            <div class="carousel-caption d-none d-md-block">
              <h3></h3>
              <p></p>
            </div>
          </div>
          <!-- Slide Two - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('img/image3.jpg')">
            <div class="carousel-caption d-none d-md-block">
              <h3></h3>
              <p></p>
            </div>
          </div>
          <!-- Slide Three - Set the background image for this slide in the line below -->
          <div class="carousel-item" style="background-image: url('img/image4.png')">
            <div class="carousel-caption d-none d-md-block">
              <h3></h3>
              <p></p>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </header>

    <!-- Page Content -->
    <div class="container">

      <center><h1 class="my-3"><img src="img/handshake.png">&nbsp;Wiki Health Innovation: A Health-Care Stop For Everyone</h1><center>

      <!-- Marketing Icons Section -->
       <div class="row">
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-primary o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fas fa-tint"></i>
                  </div>
                  <div class="mr-5">Medicine Search</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="medicine.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-warning o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fa fa-plus-square"></i>
                  </div>
                  <div class="mr-5">Equipment/Device <br>Search </div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="equipment.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-success o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fa fa-phone"></i>
                  </div>
                  <div class="mr-5">General Search</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="doodle/index.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
              <div class="card text-white bg-danger o-hidden h-100">
                <div class="card-body">
                  <div class="card-body-icon">
                    <i class="fa fa-medkit"></i>
                  </div>
                  <div class="mr-5">Substitute Drugs</div>
                </div>
                <a class="card-footer text-white clearfix small z-1" href="substitutemedicine.php">
                  <span class="float-left">View Details</span>
                  <span class="float-right">
                    <i class="fas fa-angle-right"></i>
                  </span>
                </a>
              </div>
            </div>
			
          </div>

      <!-- /.row -->

      

      <!-- Features Section -->
<!--
      <div class="row">
        <div class="col-lg-6">
          <h2>Unique Features Provided By Us:</h2>
          <p></p>
         <div align="center"> <ul align="justify">
            <li>
              <strong>Users can interact with the Registered Doctors through the chatroom facility and can
get the digitalized prescription.</strong>
            </li>
            <li><strong>Users and Doctors can find the prescribed drugs and its substitute availability in the
nearby pharmacy.</strong></li>
            <li><strong>Registered Pharmacies can also maintain their sales, customers and product record in
our database.</strong></li>
            <li><strong> Registered Hospitals can maintain their blood inventories record in our centralized
database.</strong></li>
            <li><strong> Registered Hospitals can maintain their blood inventories record in our centralized
database.</strong></li>
			<li><strong>Registered Doctors will get the facility to store their patients records in the database.</strong></li>
          <li><strong>We also provide a Management Information System to track their daily activities and
generate reports for further analysis.</strong></li>
		  </ul></div>
		  
          <p align="justify"></p>
        </div>
        <div class="col-lg-6">
		<br><br><br><br>
          <img class="img-fluid rounded" src="img/unique.jpg" alt="">
        </div>
      </div>
-->
      <!-- /.row -->

      <hr>

    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Wiki Health Innovation 2020</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>

</html>
